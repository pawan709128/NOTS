a=10
b=20
c=a+b
print(a)
print(b)
print(c)
