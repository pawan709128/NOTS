# Program for computing sum of two numbers
a = 10
b = 20
c = a+b
print("------------------------")
print("Val of a=", a)
print("Val of b=", b)
print("Sum=", c)
print("------------------------")
