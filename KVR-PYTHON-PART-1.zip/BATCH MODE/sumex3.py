#Program for Computing sum of two numbers
a=int(input("Enter Value of a:"))
b=int(input("Enter Value of b:"))
c=a+b
print("************************")
print("Val of a=",a)
print("Val of b=",b)
print("Sum=",c)
print("************************")
