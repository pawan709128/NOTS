#This Program computes sum of two numbers
a=10
b=20
c=a+b
print("-"*30)
print("Val of a=",a)
print("Val of b=",b)
print("sum=",c)
print("*"*30)
