#Test.py
a=10
b=20
c=a+b
print("sum({},{})={}".format(a,b,c))