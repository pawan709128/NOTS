#Non-GenEx1.py
r=range(10,100,5)
for val in r:
	print(val)