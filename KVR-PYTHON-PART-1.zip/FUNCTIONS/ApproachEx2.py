#Program for defining a Function for cal Mul of two numbers
#ApproachEx2.py
#INPUT---------->Taking in Function Body
#PROCESS-------->Done in Function Body
#RESULT OR OUTPUT-->Displayed in Function Body
def mulop():
    #Input
    a=float(input("Enter First Value:"))
    b=float(input("Enter Second Value:"))
    #Procees
    c=a*b
    #result
    print("Mul({},{})={}".format(a,b,c))

#main program
mulop() # Function call