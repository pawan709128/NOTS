#Program for demonstarting filter()
#FilterEx3.py
def posvalue(n):
	if(n>0):
		return True
	else:
		return False


#main program
print("Enter List of Values Separated by Space:")
lst=[int(val) for val in input().split()]
pslist=list(filter(posvalue,lst))
print("Given List=",lst)
print("Possitive Elements List=",pslist)