#ReadValuesComprehenEx1.py
print("Enter List of values separated by space:")
kbddata=input()
print("Data=",kbddata)