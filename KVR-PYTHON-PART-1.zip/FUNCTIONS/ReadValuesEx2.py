#ReadValuesEx2.py
print("Enter List of Values Separated By space:")
lst=[float(val) for val in input().split()]
print("Content of list=",lst)
