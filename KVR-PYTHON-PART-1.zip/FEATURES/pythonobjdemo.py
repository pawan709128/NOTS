#pythonobjdemo.py
class Student:pass


s=Student()  # Object Creation
s.sno=100
s.sname="Rossum"
s.marks=22.22
print(s.sno,s.sname,s.marks)
s.cname="OUCET"
print(s.sno,s.sname,s.marks,s.cname)
s.addr="HYD"
s.dob="13-03-2033"
print(s.sno,s.sname,s.marks,s.cname,s.addr,s.dob)
