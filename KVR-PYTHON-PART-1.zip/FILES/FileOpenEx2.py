#Program demonstarting opening the files
#FileOpenEx2.py
fp=open("stud.data","w")
print("\nType of fp=",type(fp))
print("File Opened in Write Mode Sucessfully")