#ImportSyntax-4.py
import icici as i,MathsInfo as m,aop as a
print("Bank Name:{}".format(i.bname))
print("Bank Addresss:{}".format(i.addr))
i.simpleint()
print("-------------------------------------------")
print("val of PI=",m.PI)
print("val of E=",m.E)
print("-------------------------------------------")
a.mulop(100,200)
print("-------------------------------------------")