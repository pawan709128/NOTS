#PrimeDemo.py
from Prime import decideprime
decideprime(int(input("Enter any number to decide prime or not:")))