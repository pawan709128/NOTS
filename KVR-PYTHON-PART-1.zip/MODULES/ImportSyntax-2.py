#ImportSyntax-2.py
import icici,MathsInfo,aop
print("Bank Name:{}".format(icici.bname))
print("Bank Addresss:{}".format(icici.addr))
icici.simpleint()
print("-------------------------------------------")
print("val of PI=",MathsInfo.PI)
print("val of E=",MathsInfo.E)
print("-------------------------------------------")
aop.sumop(100,200)
print("-------------------------------------------")