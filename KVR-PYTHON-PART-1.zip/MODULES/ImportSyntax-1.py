#ImportSyntax-1.py
import icici
import MathsInfo
import aop
print("Bank Name:{}".format(icici.bname))
print("Bank Addresss:{}".format(icici.addr))
icici.simpleint()
print("-------------------------------------------")
print("val of PI=",MathsInfo.PI)
print("val of E=",MathsInfo.E)
print("-------------------------------------------")
aop.sumop(100,200)
print("-------------------------------------------")