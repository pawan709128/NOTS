#SE2.py
import aop
aop.sumop(10,20)
aop.subop(10,20)
aop.mulop(10,20)