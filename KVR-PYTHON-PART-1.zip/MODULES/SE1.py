#SE1.py
import MathsInfo
#Here SE1 is trying to Re-use the global Variables of one program in another program
print("val of PI=",MathsInfo.PI)
print("val of E=",MathsInfo.E)