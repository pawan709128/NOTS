#FromImportSyntax-3.py
from icici import *
from MathsInfo import *
from aop import *
print("Bank Name:{}".format(bname))
print("Bank Addresss:{}".format(addr))
simpleint()
print("-------------------------------------------")
print("val of PI=",PI)
print("val of E=",E)
print("-------------------------------------------")
sumop(100,200)
mulop(10,20)
print("-------------------------------------------")