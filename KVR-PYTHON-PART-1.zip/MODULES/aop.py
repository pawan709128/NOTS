#aop.py--File Name and acts as Module name
def  sumop(a,b):
	print("sum({},{})={}".format(a,b,a+b))

def  subop(a,b):
	print("sub({},{})={}".format(a,b,a-b))

def  mulop(a,b):
	print("mul({},{})={}".format(a,b,a*b))


