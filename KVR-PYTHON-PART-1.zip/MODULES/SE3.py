#SE3.py
import icici
print("Bank Name:{}".format(icici.bname))
print("Bank Addresss:{}".format(icici.addr))
icici.simpleint()
