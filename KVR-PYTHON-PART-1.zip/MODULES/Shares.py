#Shares.py---File Name and Module Name
def  sharesinfo():
	d={"IT":5,"Fin":4,"Auto":3,"Pharma":2}
	return d
