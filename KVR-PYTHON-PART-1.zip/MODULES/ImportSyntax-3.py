#ImportSyntax-3.py
import icici as i
import MathsInfo as m
import aop as a
print("Bank Name:{}".format(i.bname))
print("Bank Addresss:{}".format(i.addr))
i.simpleint()
print("-------------------------------------------")
print("val of PI=",m.PI)
print("val of E=",m.E)
print("-------------------------------------------")
a.sumop(100,200)
print("-------------------------------------------")