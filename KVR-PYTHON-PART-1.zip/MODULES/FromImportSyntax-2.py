#FromImportSyntax-2.py
from icici import bname as b ,addr as a ,simpleint as si
from MathsInfo import PI as p,E
from aop import sumop as ap,subop as sp
print("Bank Name:{}".format(b))
print("Bank Addresss:{}".format(a))
si()
print("-------------------------------------------")
print("val of PI=",p)
print("val of E=",E)
print("-------------------------------------------")
ap(100,200)
sp(10,20)
print("-------------------------------------------")