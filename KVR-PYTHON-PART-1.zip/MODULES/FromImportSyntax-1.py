#FromImportSyntax-1.py
from icici import bname,addr,simpleint
from MathsInfo import PI,E
from aop import sumop,subop
print("Bank Name:{}".format(bname))
print("Bank Addresss:{}".format(addr))
simpleint()
print("-------------------------------------------")
print("val of PI=",PI)
print("val of E=",E)
print("-------------------------------------------")
sumop(100,200)
subop(10,20)
print("-------------------------------------------")