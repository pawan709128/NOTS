#AopMenu.py
def menu():
    s="""\t\t=================================================
            Arithemtic Operations
        =================================================
            1. Addition
            2. Substraction
            3. Multiplications
            4. Normal Division
            5. Floor Division
            6. Modulo Division
            7. Expoentiation
            8. Exit
        ================================================"""
    print(s)

