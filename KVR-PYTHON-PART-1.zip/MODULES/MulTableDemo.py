#MulTableDemo.py
from MulTable import table
table(int(input("Enter a number for generating mul table:")))