#Square.py----File Name and Module Name
def  area():
	s=float(input("Enter Side for Area:"))
	sa=s**2
	print("Area of Square={}".format(sa))

def  peri():
	s=float(input("Enter Side for Peri:"))
	sp=4*s
	print("Perimeter of Square={}".format(sp))
