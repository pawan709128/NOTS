#FigureMenu.py----File Name and module Name
def menu():
	s="""\t==================================================
		Different Figures
	==================================================
		1. Circle Area
		2. Circle Perimter
		3. Square Area
		4. Square Perimeter
		5. Rectangle Area
		6. Rectange Perimter
		7. Triangle Area 
		8. Triangle Perimeter(p=a+b+c)
		9. Exit
	=================================================="""
	print(s)