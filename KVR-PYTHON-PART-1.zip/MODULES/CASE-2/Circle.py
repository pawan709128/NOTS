#Circle.py----File Name and Module Name
def  area():
	r=float(input("Enter Radius for Area:"))
	ac=3.14*r**2
	print("Area of Circle={}".format(ac))

def  peri():
	r=float(input("Enter Radius for Peri:"))
	pc=2*3.14*r
	print("Perimeter of Circle={}".format(pc))
