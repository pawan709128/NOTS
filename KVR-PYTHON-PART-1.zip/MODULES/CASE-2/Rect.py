#Rect.py----File Name and Module Name
def  area():
	l,b=float(input("Enter Length for Area:")),float(input("Enter Breadth for Area:"))
	ra=l*b
	print("Area of rectangle={}".format(ra))

def  peri():
	l,b=float(input("Enter Length for Peri:")),float(input("Enter Breadth for Peri:"))
	pr=2*(l+b)
	print("Peri of rectangle={}".format(pr))

