#MathsInfo.py---File Name and  acts as Module name
PI=3.14
E=2.71  # here PI and E are called Global variables
