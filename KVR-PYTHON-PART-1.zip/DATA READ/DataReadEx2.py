#DataReadEx2.py
print("Enter Two Values")
a=input()
b=input()
#convert a and b into float type
x=float(a)
y=float(b)
z=x*y
print("Mul({},{})={}".format(x,y,z))
