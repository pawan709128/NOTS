#DataReadEx3.py
print("Enter Two Values")
x=float(input()) # Reading the data and converting
y=float(input()) # Reading the data and converting
z=x*y
print("Mul({},{})={}".format(x,y,z))