#program for Multiplication of two Numbers
print("Enter First value:")
s1=input()
print("Enter Second Value:")
s2=input()
#Convert s1 and s2 into float type
a=float(s1)
b=float(s2)
#multiply
c=a*b
#display the result
print("Mul({},{})={}".format(a,b,c))

