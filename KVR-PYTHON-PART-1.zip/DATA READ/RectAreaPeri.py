#Program cal area and Perimeter of rectangle
#RectAreaPeri.py
l=float(input("Enter Length:"))
b=float(input("Enter Breadth:"))
#cal area and Peri of rectangle
ar=l*b
pr=2*(l+b)
print("="*50)
print("\tLength={}".format(l))
print("\tBreadth={}".format(b))
print("\tArea of Rect={}".format(ar))
print("\tPeri.of Rect:{}".format(pr))
print("="*50)

