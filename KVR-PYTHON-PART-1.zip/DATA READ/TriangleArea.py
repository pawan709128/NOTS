#Program for acl area of Triangle
#TriangleArea.py
b=float(input("Enter Base:"))
h=float(input("Enter Height:"))
#cal area of Triangle
at=1/2*b*h
print("="*50)
print("\tBase:{}".format(b))
print("\tHeight:{}".format(h))
print("\tArea of Triangle:{}".format(at))
print("="*50)
