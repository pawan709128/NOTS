#Program for cal area of Circle
#CircleArea.py
r=float(input("Enter Radious:"))
ac=3.14*r*r
print("="*50)
print("Radius:{}".format(r))
print("Area of Circle:%0.2f" %ac)
print("="*50)

