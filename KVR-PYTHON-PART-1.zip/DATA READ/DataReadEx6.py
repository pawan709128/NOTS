#program for Multiplication of two Numbers
#DataReadEx6.py
x=float(input("Enter First Value:"))
y=float(input("Enter Second Value:"))
print("Mul({},{})={}".format(x,y,x*y))
