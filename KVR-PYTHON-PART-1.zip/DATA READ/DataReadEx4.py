#DataReadEx4.py
print("Enter Two Values")
x=float(input()) # Reading the data and converting
y=float(input()) # Reading the data and converting
print("Mul({},{})={}".format(x,y,x*y))