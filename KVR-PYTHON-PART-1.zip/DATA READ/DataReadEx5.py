#program for Multiplication of two Numbers
#DataReadEx5.py
a=input("Enter First Value:")
b=input("Enter Second Value:")
#convert a  and b into float type
x=float(a)
y=float(b)
z=x*y
print("Mul({},{})={}".format(x,y,z))