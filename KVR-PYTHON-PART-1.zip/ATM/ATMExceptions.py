#ATMExceptions.py
class DepositError(Exception):pass
class WithDrawError(BaseException):pass
class  InSuffFundError(Exception):pass