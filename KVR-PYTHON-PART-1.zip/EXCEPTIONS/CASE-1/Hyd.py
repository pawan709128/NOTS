#Development of Exception
#Hyd.py--File name and module name
			#  (1)					(2)
class HydDivisionError(Exception):pass