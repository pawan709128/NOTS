#Ex1.py
print("Program Execution Started:")
a=10
b=0
print("a={} b={}".format(a,b))
c=a/b
print("Div={}".format(c))
print("Program Execution Ended:")
