#Program for accepting Two Numerical Values from KBD and Find their Div
#DivEx1.py
s1=input("Enter First Value:")
s2=input("Enter Second Value:")
a=int(s1) # exception generated statement--problemtaic statement
b=int(s2) # exception generated statement--problemtaic statement
c=a/b      # exception generated statement--problemtaic statement
print("Div={}".format(c))
