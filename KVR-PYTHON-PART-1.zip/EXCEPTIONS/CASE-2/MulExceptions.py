#development of exception for generating multable
#MulExceptions.py--File Name and Module Name
class ZeroError(Exception):pass
class NegNumError(BaseException):pass
