#MovieeEx1.py
tkt=input("Do u have Ticket(yes/no):")
if (tkt=="yes"):
    print("enter into theater")
    print("watch the moviee")
    print("eat pop corn!!")
print("Goto Home")

