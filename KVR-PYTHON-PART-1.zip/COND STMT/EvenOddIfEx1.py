#Program for deciding wether the number is even or odd
#EvenOddIfEx1.py
n=int(input("Enter a Number:")) # 100
if(n%2==0):
    print('{} is EVEN'.format(n))
if(n%2!=0):
    print("{} is ODD".format(n))
print("Program execution Completed")