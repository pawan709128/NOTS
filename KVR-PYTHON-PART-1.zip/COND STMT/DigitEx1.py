#DigitEx1.py
d={0:"ZERO",1:"ONE",2:"TWO",3:"THREE",4:"FOUR",5:"FIVE",6:"SIX",7:"SEVEN",8:"EIGHT",9:"NINE"}
digit=int(input("Enter a Digit:")) # 0 1  2  3 4  5 6 7 8 9
res=d.get(digit)
if(res!=None):
    print("{} is {}".format(digit,res))
else:
    print("{} is a Number".format(digit))


