#ReadValuesComprehenEx2.py
print("Enter List of Values separated by comma:")
lst=[ val  for val in input().split(",")]
print("Given List:{}".format(lst))
