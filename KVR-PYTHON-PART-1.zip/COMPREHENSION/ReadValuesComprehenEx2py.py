#ReadValuesComprehenEx2py
print("Enter List of Values separated by comma:")
lst=[  str(val)  for val in input().split(",")]
print("Given List:{}".format(lst))