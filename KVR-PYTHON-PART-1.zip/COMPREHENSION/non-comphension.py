#non-comphension.py
lst=[3,6,12,7,19,25]
sqlist=[]
for val in lst:
	sqlist.append(val**2)
else:
	print("Given List=",lst)
	print("Square  List=",sqlist)