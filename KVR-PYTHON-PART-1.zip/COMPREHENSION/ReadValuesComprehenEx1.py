#ReadValuesComprehenEx1.py
print("Enter List of values separated by space:")
lst=[ int(val)   for val in input().split()]
print("Given List=",lst)
