#icicidemo.py
from icici import bname,addr,simpleint
print("Bank Name:{}".format(bname))
print("Bank Address:{}".format(addr))
simpleint()