#Program for accepting Three  valuea  and find Biggest among them and check for equality
#BigThreeEx1.py
a=int(input("Enter Value of a:")) # 100
b=int(input("Enter Value of b:")) # 500
c=int(input("Enter Value of c:")) # 4000
#Logic for big among three
bv=a if a>=b and a>c else b if b>a and b>=c else c if c>=a and c>b else "All values are equal"
print("big({},{},{})={}".format(a,b,c,bv))
