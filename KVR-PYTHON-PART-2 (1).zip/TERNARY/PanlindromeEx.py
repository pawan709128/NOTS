#PanlindromeEx.py
word=input("Enter Word:")
res="PALINDROME" if word==word[::-1] else "NOT PALINDROME"
print("{} is {}".format(word,res))

