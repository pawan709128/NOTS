#program for Finding Biggest of Two Numbers
#BigEx1.py
a=int(input("Enter First value:"))
b=int(input("Enter Second value:"))
#Logic for Finding biggest
bv= a if a>b else b
print("big({},{})={}".format(a,b,bv))

