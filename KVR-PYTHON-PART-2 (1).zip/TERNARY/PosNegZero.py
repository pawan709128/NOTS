#PosNegZero.py
n=int(input("Enter any Number:")) # +ve   -ve   0
res="+VE" if n>0 else "-VE" if n<0 else "ZERO"
print("{} is {}".format(n,res))



