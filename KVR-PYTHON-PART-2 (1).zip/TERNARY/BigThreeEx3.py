#Program for accepting Three  valuea  and find Biggest among them and check for equality
#BigThreeEx3.py
a=int(input("Enter Value of a:")) # 100
b=int(input("Enter Value of b:")) # 500
c=int(input("Enter Value of c:")) # 4000
#Logic for big among three
bv=a if b<=a>c else b if a<b>=c else c if a<=c>b else "All values are equal"
print("big({},{},{})={}".format(a,b,c,bv))
