#Program for removing a File Name
#FileRemoveEx1.py
import os
try:
	os.remove("D:\KVR-PYTHON-6PM\FILES\stud1.data")
	print("File Removed Sucessfully--Verify")
except FileNotFoundError:
	print("File does not exist")