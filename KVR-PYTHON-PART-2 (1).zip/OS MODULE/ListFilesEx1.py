#Program for Listing the files in the folder---listdir()
#ListFilesEx1.py
import os
try:
	fileslist=os.listdir("D:\KVR-PYTHON-6PM\FILES")
	print("------------------------------------------")
	print("List of Files :")
	print("Number of Files={}".format(len(fileslist)))
	print("------------------------------------------")
	for filename in fileslist:
		print("\t{}".format(filename))
	print("------------------------------------------")
except FileNotFoundError:
	print("Folder does not exist")
