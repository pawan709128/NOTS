#Program for creating a Folder---mkdir()
#CreateFolderEx1.py
import os
try:
	os.mkdir("C:\\BANG\\PYTHON")
	print("Folder Created Sucessfully ")
except FileNotFoundError:
	print("Root Folder  Does not Exist")
except FileExistsError:
	print("Folder already Exist")