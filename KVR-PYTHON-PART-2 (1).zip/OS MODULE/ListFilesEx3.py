#Program for Listing the Python files(.py) in the folder---listdir()
#ListFilesEx3.py
import os
try:
	foldername=input("Enter the Folder Name:")
	fileslist=os.listdir(foldername)
	print("------------------------------------------")
	print("List of Files :")
	nop=0
	print("Number of Files={}".format(len(fileslist)))
	print("------------------------------------------")
	for filename in fileslist:
		print("\t{}".format(filename))
	print("------------------------------------------")
except FileNotFoundError:
	print("Folder does not exist")
