#program for removing a Folder--rmdir()
#RemoveFolderEx1.py
import os
try:
	os.rmdir("C:\INDIA\HYD\AMPT\PYTHON\KVR")
	print("Folder Removed Successfully --veriry")
except  FileNotFoundError:
	print("Folder  Does not Exist")
except OSError:
	print("Folder is not empty--plz Check")