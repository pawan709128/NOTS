#Program for Listing the Python files(.py) in the folder---listdir()
#ListFilesEx2.py
import os
try:
	fileslist=os.listdir("D:\KVR-PYTHON-6PM\FILES")
	print("------------------------------------------")
	print("List of Files :")
	nop=0
	print("Number of Files={}".format(len(fileslist)))
	print("------------------------------------------")
	for filename in fileslist:
		if(filename[-3:]==".py"):
			print("\t{}".format(filename))
			nop=nop+1
	print("------------------------------------------")
	print("Number of Python File={}".format(nop))
	print("------------------------------------------")
except FileNotFoundError:
	print("Folder does not exist")
