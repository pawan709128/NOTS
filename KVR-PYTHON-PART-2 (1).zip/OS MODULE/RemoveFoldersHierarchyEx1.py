#program for removing a Folders Hierarchy--removedirs()
#RemoveFoldersHierarchyEx1.py
import os
try:
	os.removedirs("C:\INDIA\HYD\AMPT\python")
	print("Folder Removed Successfully --veriry")
except  FileNotFoundError:
	print("Folder(s) hierarchy  Does not Exist")
except OSError:
	print("Folder is not empty--plz Check")