#Program renaming a Folder--rename()
#RenameFolderEx1.py
import os
try:
	os.rename("C:\KVR\java","C:\KVR\PYTHON")
	print("Folder Name re-named--verify")
except FileNotFoundError:
	print("Folder  does not exist")

