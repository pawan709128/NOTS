#Program for creating a Folders Hierarchy---makedirs()
#CreateFoldersHierarchyEx1.py
import os
try:
	os.makedirs("C:\\BANG")
	print("Folders hierarchy Created--verify")
except FileExistsError:
	print("Folders hierarchy already Exist")