#Program renaming a File--rename()
#RenameFileEx1.py
import os
try:
	os.rename("D:\KVR-PYTHON-6PM\FILES\student2.data","D:\KVR-PYTHON-6PM\FILES\stud2.data")
	print("File Name re-named--verify")
except FileNotFoundError:
	print("File does not exist")

