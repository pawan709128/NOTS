#program for demnonstrating random Choce Value from any Iterable object--captcha Code
#choiceex3.py
import random as r
cap="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()_+="
for i in range(1,10):
	print(r.choice(cap),r.choice(cap),r.choice(cap),r.choice(cap),r.choice(cap))

"""
D:\KVR-PYTHON-6PM\RANDOM>py choiceex3.py
C M ! 2 F
u W s 0 *
X J = M s
Y P b 5 P
T 8 X v q
R x j D 1
P i ( w h
S L _ A B
M l # 4 @
"""