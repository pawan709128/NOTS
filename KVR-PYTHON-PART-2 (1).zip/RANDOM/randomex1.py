#program for generating random floating point values between 0.0 to 1.0--random()
#randomex1.py
from random import random
for i in range(1,6):
	print(random())
print("---------------OR-----------------------")
for i in range(1,6):
	print("%0.3f" %random())
print("---------------OR-----------------------")
for i in range(1,6):
	print(round(random(),2))

"""
D:\KVR-PYTHON-6PM\RANDOM>py randomex1.py
0.9793648027983883
0.08749143415787031
0.8938371308045829
0.6104902612716221
0.6244688112926148
---------------OR-----------------------
0.633
0.582
0.013
0.398
0.176
---------------OR-----------------------
0.81
0.77
0.64
0.92
0.72
"""