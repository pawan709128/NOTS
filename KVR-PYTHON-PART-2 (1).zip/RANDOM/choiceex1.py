#program for demnonstrating random Choce Value from any Iterable object
#choiceex1.py
import random as r
s="HYDERABAD"
for i in range(1,6):
	print(r.choice(s))
print("--------------------------------------------------")
lst=[10,"Rossum",34.56,True,2+6j,False,"Python"]
for i in range(1,6):
	print(r.choice(lst))
print("--------------------------------------------------")


"""
--------------------------------------------------

D:\KVR-PYTHON-6PM\RANDOM>py choiceex1.py
Y
D
H
A
D
--------------------------------------------------
10
(2+6j)
Python
34.56
(2+6j)
--------------------------------------------------
"""