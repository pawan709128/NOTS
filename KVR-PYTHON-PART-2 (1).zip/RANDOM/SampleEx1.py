#program for demnonstrating random sampling values from any Iterable object
#SampleEx1.py
from random import sample
s="PYTHON"
for i in range(1,6):
	k=""
	lst=sample(s,k=3)
	k=k.join(lst)
	print(k)
