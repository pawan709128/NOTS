#program for generating random floating point values between 10 to 12--uniform()
#uniformex.py
from random import uniform
for i in range(1,6):
	print(uniform(10.5,12))
print("---------------OR-----------------------")
for i in range(1,6):
	print("%0.3f" %uniform(10.5,12))
print("---------------OR-----------------------")
for i in range(1,6):
	print(round(uniform(10.5,12),2))


""""
D:\KVR-PYTHON-6PM\RANDOM>py uniformex.py
10.69204330380328
11.039112959695647
10.875764502472572
11.49883288815713
11.679105477134472
---------------OR-----------------------
10.648
11.194
11.928
11.404
10.664
---------------OR-----------------------
10.53
11.61
11.9
10.64
11.35
"""