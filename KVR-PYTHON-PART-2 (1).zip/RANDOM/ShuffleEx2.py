#Program re-shuffling Or Re-oraganizng the elements of str object--by using shuffle()
#ShuffleEx2.py
import random as r
s="HYDERABAD"
lst=list(s)
for i in range(1,len(s)):
	r.shuffle(lst)
	k=""
	k=k.join(lst)
	print(k)


"""
D:\KVR-PYTHON-6PM\RANDOM>py ShuffleEx2.py
DBDAEAYHR
EDRYHBDAA
AYHDBARDE
DEAAHBDRY
EYABHDRDA
DAYHRBEAD
AHDABEYRD
ERDAYAHDB
"""