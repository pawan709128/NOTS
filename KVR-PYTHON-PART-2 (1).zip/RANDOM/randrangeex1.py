#program for generating random Integer Values between 10 and 20 --randrange()
#randrangeex1.py
import random as r
for i in range(1,6):
	print(r.randrange(10,20))


"""
D:\KVR-PYTHON-6PM\RANDOM>py randrangeex1.py
17
11
11
12
18
"""