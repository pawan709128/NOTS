#program for demnonstrating random sampling values from any Iterable object
#SampleEx2.py
import random as r
cap="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()_+="
for i in range(1,10):
	lst=r.sample(cap,k=5)
	k=""
	k=k.join(lst)
	print(k)

"""
D:\KVR-PYTHON-6PM\RANDOM>py SampleEx2.py
liNQb
q6(_E
9!2Uj
ieBTO
aibL@
&!lu@
Fp9hw
hAW_V
6@QR5
"""