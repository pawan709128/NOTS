#program for demnonstrating random sampling values from any Iterable object
#SampleEx3.py
import random as r
state=["TS","AP"]
rtcode=["09","08","07","06","39"]
nums="0123456789"
alphs="ABCDEFGHIJKLMNOPQRSTUVWXYZ"    
#numberplate:    TS08 HF 8558     TS08HL3600
for i in range(1,10):
	st1=r.sample(state,1)
	rc=r.sample(rtcode,1)
	lets=r.sample(alphs,2)
	no=r.sample(nums,4)
	sst1=""
	sst1=sst1.join(st1)
	src=""
	src=src.join(rc)
	slets=""
	slets=slets.join(lets)
	sno=""
	sno=sno.join(no)
	numberplate=sst1+src+" "+slets+" "+sno
	print(numberplate)

"""
D:\KVR-PYTHON-6PM\RANDOM>py SampleEx3.py
AP39 AX 5498
TS06 MK 1072
AP08 QE 2360
AP07 MC 6304
TS08 FU 4396
TS09 MQ 1309
TS07 BY 6783
TS06 UF 3016
AP39 LR 5138
"""