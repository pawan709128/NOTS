#Program re-shuffling Or Re-oraganizng the elements of mutable objects--by using shuffle()
#ShuffleEx1.py
import random as r
lst=[10,"HYD",45.67,True,"Rajesh","Python",2+3j]
for i in range(1,6):
	r.shuffle(lst)
	print(lst)