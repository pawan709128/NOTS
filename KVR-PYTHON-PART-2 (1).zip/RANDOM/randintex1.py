#program for generating random Integer Values between 10 and 20 --randint()
#randintex1.py
import random as r
for i in range(1,6):
	print(r.randint(10,20))


"""
D:\KVR-PYTHON-6PM\RANDOM>py randintex1.py
20
11
10
18
10
"""