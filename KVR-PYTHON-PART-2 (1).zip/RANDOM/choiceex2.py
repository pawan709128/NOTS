#program for demnonstrating random Choce Value from any Iterable object--captcha Code
#choiceex2.py
import random as r
Upperalphs="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
Loweralphs="abcdefghijklmnopqrstuvwxyz"
digits="0123456789"
sps="!@#$%^&*()_+="
for i in range(1,10):
	print(r.choice(Upperalphs),r.choice(Loweralphs),r.choice(digits),r.choice(sps))

"""
N t 9 @
R w 2 %
N i 5 ^
G d 5 &
U x 4 (
V x 6 =
V c 1 #
V t 2 =
D k 3 (
"""