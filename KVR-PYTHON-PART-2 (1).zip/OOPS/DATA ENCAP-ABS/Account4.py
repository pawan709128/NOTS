#Account4.py------File name and Module Name ----Data Encapsulation
class __Account:
	def  getaccdetails(self):
		self.acno=1234
		self.cname="Naresh"
		self.bal=3.4
		self.pin=8989
		self.bname="SBI"


#Note: Once we we make  class name preceded with __ then that class name can't be imported in Other Programs.