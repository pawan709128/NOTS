#others4.py--Data Abstraction
from Account4 import Account # will get Error bcoz Account made as encapsulated __Account
ac=Account()
ac.getaccdetails()
print("Account Number:{}".format(ac.acno))
print("Account Holder Name:{}".format(ac.cname))
print("Account Balance:{}".format(ac.bal))
print("Account Pin:{}".format(ac.pin))
print("Account Branch Name:{}".format(ac.bname))