#Account3.py------File name and Module Name ----Data Encapsulation
class Account:
	def  __getaccdetails(self):
		self.acno=1234
		self.cname="Naresh"
		self.bal=3.4
		self.pin=8989
		self.bname="SBI"
