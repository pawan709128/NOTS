#Account1.py------File name and Module Name ----Data Encapsulation
class Account:
	def  __init__(self):
		self.__acno=1234
		self.cname="Naresh"
		self.__bal=3.4
		self.__pin=8989
		self.bname="SBI"
