#Program for default and Parameterized Constructor
#DefaultParamConstEx1.py
class Test:
	def __init__(self,a=1,b=2):
		print("Default / Parametrized Constructor")
		self.a=a
		self.b=b
		print("----------------------------------------")
		print("Val of a:{}".format(self.a))
		print("Val of b:{}".format(self.b))
		print("----------------------------------------")


#main program
t1=Test() # Object Creation--PVM Calls Default Constructor
t2=Test(10,20) # Object Creation--PVM Calls Parameterized Constructor
t3=Test(100) # Object Creation--PVM Calls Parameterized Constructor
t4=Test(b=100) # Object Creation--PVM Calls Parameterized Constructor
t5=Test(b=1000,a=2000) # Object Creation--PVM Calls Parameterized Constructor