#Non-Const.ex.py
class Employee:
	def getempdata(self):
		self.eno=10
		self.ename="Rossum"



#main program
e1=Employee() # Object Creation
print("Content of e1=",e1.__dict__) # {}
e1.getempdata() # We are calling the method Explicitly
print("Content of e1=",e1.__dict__) # {........}