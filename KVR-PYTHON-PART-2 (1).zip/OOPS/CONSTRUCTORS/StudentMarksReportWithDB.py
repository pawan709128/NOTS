#program for Generating student Marks Report
#StudentMarksReportWithDB.py
#Validation of Student Number
class StudentMarksReport:
	def __init__(self):
		while(True):
			self.sno=int(input("Enter Student Number:"))
			if(self.sno>0):
				break
			print("\t{} Is Invalid Student Number:".format(self.sno))
		#Accept Student Name
		self.sname=input("Enter Student Name:")
		#Validation of C lang Marks(0-100)
		while(True):
			self.cm=int(input("Enter Marks in C:"))
			if(self.cm>=0) and (self.cm<=100):
				break
			print("\t{} Is Invalid Marks in C:".format(self.cm))
		#Validation of CPP lang Marks(0-100)
		while(True):
			self.cppm=int(input("Enter Marks in C++:"))
			if(0<=self.cppm<=100):
				break
			print("\t{} Is Invalid Marks in C++:".format(self.cppm))

		#Validation of PYTHON lang Marks(0-100)
		while(True):
			self.pym=int(input("Enter Marks in PYTHON:"))
			if(0<=self.pym<=100):
				break
			print("\t{} Is Invalid Marks in PYTHON:".format(self.pym))
	def compute(self):
		#Compute TotalMarks and Percentage
		self.totmarks=self.cm+self.cppm+self.pym
		self.percent=(self.totmarks/300)*100
		#Decide the grade
		if(self.cm<40)  or  (self.cppm<40) or (self.pym<40):
			self.grade="FAIL"
		else:
			if(self.totmarks>=250) and (self.totmarks<=300):
				self.grade="DISTINCTION"
			elif(self.totmarks>=200) and (self.totmarks<=249):
				self.grade="FIRTST"
			elif(self.totmarks>=150) and (self.totmarks<=199):
				self.grade="SECOND"
			elif(self.totmarks>=120) and (self.totmarks<=149):
				self.grade="THIRD"
	def dispmarksreport(self):
		#Display Student Marks Report
		print("="*50)
		print("\t\tStudent Marks Report:")
		print("="*50)
		print("\tStudent Number:{}".format(self.sno))
		print("\tStudent Name:{}".format(self.sname))
		print("\tStudent Marks in C:{}".format(self.cm))
		print("\tStudent Marks in C++:{}".format(self.cppm))
		print("\tStudent Marks in PYTHON:{}".format(self.pym))
		print("-"*50)
		print("\tStudent Total Marks:{}".format(self.totmarks))
		print("\tStudent Percentage of Marks:{}".format(self.percent))
		print("\tStudent Grade:{}".format(self.grade))
		print("="*50)


#main program
so=StudentMarksReport()
so.compute()
so.dispmarksreport()


