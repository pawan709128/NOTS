#Program for demonstrating Destructors
#GCEX2.py
import time,sys,gc
class Employee:
	def __init__(self,eno,ename):
		print("I am from Constructor")
		self.eno=eno
		self.ename=ename
		print("--------------------------------------------------")
		print("Employee Number:{}".format(self.eno))
		print("Employee Name:{}".format(self.ename))
		print("--------------------------------------------------")
	def __del__(self):
		print("Garbage Collectors calls __del__(self) for De-allocating Mem Space")
		global totmemspace
		totmemspace=totmemspace-sys.getsizeof(self)
		print("Now Avaliable Memory Space:{}".format(totmemspace))

#Main program
print("Program Execution Started")
print("Initially, Is GC Running:",gc.isenabled()) # True
print("-------------------------------------------------------")
gc.disable()
print("Now, Is GC Running after disable:",gc.isenabled()) # False
time.sleep(10)
e1=Employee(10,"Rossum")
e2=Employee(20,"Travis")
e3=Employee(30,"Ritche")
#to find the memory space of any object----sys.getsize(objectname)
totmemspace=sys.getsizeof(e1)+sys.getsizeof(e2)+sys.getsizeof(e3)
print("Total Memory space =",totmemspace)
print("---------------------------------------------------------------")
print("Program Execution Ended")
print("Now, Is GC Running after disable:",gc.isenabled()) # False
time.sleep(5)