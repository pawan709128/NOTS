#program for demonstarting gabage Collector running Process
#GCEX1.py
import gc
print("Program Execution started")
print("Initially, Is GC Running:",gc.isenabled()) # True
a=100
b=200
c=a+b
print("Val of a={}".format(a))
gc.disable()
print("Val of b={}".format(b))
print("Now Is GC Running:",gc.isenabled()) # False
print("sum={}".format(c))
gc.enable()
print("Now Is GC Running:",gc.isenabled()) # True
print("Program Execution Ended")
