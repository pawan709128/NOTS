#Program for demonstrating Destructors
#non-destex1.py
class Employee:
	def __init__(self,eno,ename):
		self.eno=eno
		self.ename=ename
		print("--------------------------------------------------")
		print("Employee Number:{}".format(self.eno))
		print("Employee Name:{}".format(self.ename))
		print("--------------------------------------------------")

#Main program
print("Program Execution Started")
e1=Employee(10,"Rossum")
e2=Employee(20,"Travis")
print("Program Execution Ended")
