#Program for demonstrating Destructors
#destex2.py
import time,sys
class Employee:
	def __init__(self,eno,ename):
		print("I am from Constructor")
		self.eno=eno
		self.ename=ename
		print("--------------------------------------------------")
		print("Employee Number:{}".format(self.eno))
		print("Employee Name:{}".format(self.ename))
		print("--------------------------------------------------")
	def __del__(self):
		print("Garbage Collectors calls __del__(self) for De-allocating Mem Space")
		global totmemspace
		totmemspace=totmemspace-sys.getsizeof(self)
		print("Now Avaliable Memory Space:{}".format(totmemspace))

#Main program
print("Program Execution Started")
e1=Employee(10,"Rossum")
e2=Employee(20,"Travis")
e3=Employee(30,"Ritche")
#to find the memory space of any object----sys.getsize(objectname)
totmemspace=sys.getsizeof(e1)+sys.getsizeof(e2)+sys.getsizeof(e3)
print("Total Memory space =",totmemspace)
print("---------------------------------------------------------------")
print("Program Execution Ended")
time.sleep(5)