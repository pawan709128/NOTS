#Program for demonstring non-Inheritance ---class and objects
#Non-PloyInhEx1.py
class C1:
	def disp1(self):
		print("C1----disp1()")

class C2:
	def disp2(self):
		print("C2----disp2()")

#main program---we created 4 objects
o1=C1()
o2=C2()
o1.disp1()
o2.disp2()