#Program for demonstring Inheritance 
#Non-PolyInhEx2.py
class C1:
	def disp1(self):
		print("C1----disp1()")

class C2(C1):
	def disp2(self):
		print("C2----disp2()")

class C3(C2):
	def disp3(self):
		print("C3----disp3()")

#main program--we are creating 3 objects
o2=C3()
o2.disp1()
o2.disp2()
o2.disp3()