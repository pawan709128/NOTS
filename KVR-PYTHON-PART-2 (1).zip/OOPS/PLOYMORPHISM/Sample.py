#Sample.py
class C1:
	def disp(self): # Original Method
		print("C1----disp()--original")
		

#main program
o1=C1()
o1.disp()