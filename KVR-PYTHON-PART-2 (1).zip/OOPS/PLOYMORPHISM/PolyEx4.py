#Program for demonstring Polymorphism
#PolyEx4.py
class C1:
	def __init__(self): # Original Constructor
		print("C1----default Constructor")

class C2(C1):
	def __init__(self): # Overridden Constructor
		print("C2--default Constructor")
		
	
class C3(C2):
	def __init__(self): # Overridden Constructor
		print("C3--default Constructor")
		C2.__init__(self)
		C1.__init__(self)

#main program--we created 2 objects
print("w.r.t C3 Class")
o3=C3() # Object Creation---calls Constructor



