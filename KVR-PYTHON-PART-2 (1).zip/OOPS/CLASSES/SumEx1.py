#Program for calculating addition of Two Numbers by using Classes and Objects
#SumEx1.py
class Sum:pass

#main program
s=Sum() # Here s is called object
print("Content of s=",s.__dict__)
print("------------------------------------------------")
s.k=float(input("Enter Value of k:"))
s.v=float(input("Enter Value of v:"))
print("Content of s=",s.__dict__)
print("------------------------------------------------")
#add the values
s.r=s.k+s.v
print("------------------------------------------------")
print("First Value:{}".format(s.k))
print("Second Value:{}".format(s.v))
print("Sum :{}".format(s.r))
print("------------------------------------------------")