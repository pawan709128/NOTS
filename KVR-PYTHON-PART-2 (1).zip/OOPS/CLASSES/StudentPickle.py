#Program saving the details of Student in studentpick file
#StudentPickle.py--File Name and Module Name
import pickle
from Student import Student
class StudentPickle:
	def  savestuddata(self):
		with open("studpick.data","ab") as fp:
			#accept the student data from keyboard
			print("-"*50)
			sno=int(input("Enter Student Number:"))
			sname=input("Enter Student Name:")
			marks=float(input("Enter Student Marks:"))
			#create an object of student class
			s=Student(sno,sname,marks) # Object Creation--PVM Calls Parameterized Constructor
			print("-"*50)
			pickle.dump(s,fp)
			print("Student record saved in a file successfully")
			print("-"*50)






