#Program for adding of Two Numbers by using Classes and Object with instance Method
#SumOpEx1.py
class Sum:
	def readvalues(self):
		self.a=float(input("Enter Value of a:"))
		self.b=float(input("Enter Value of b:"))

	def addvalues(self):
		self.c=self.a+self.b

	def dispvalues(self):
		print("Val of a:{}".format(self.a))
		print("Val of b:{}".format(self.b))
		print("Sum:{}".format(self.c))

#main program
s1=Sum()
s1.readvalues()
s1.addvalues()
s1.dispvalues()