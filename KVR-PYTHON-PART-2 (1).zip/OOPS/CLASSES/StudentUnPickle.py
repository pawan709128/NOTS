#Program for reading the student records from file(studpick.data) 
#StudentUnPickle.py--File Name and Module Name
import pickle
class StudentUnPickle:
	def readstudrecords(self):
		try:
			with open("studpick.data","rb") as fp:
				print("--------------------------------------------------------")
				while(True):
					try:
						obj=pickle.load(fp)
						obj.dispstuddata()
					except EOFError:
						print("--------------------------------------------------------")
						break

				
		except FileNotFoundError:
			print("File does not exist")


