#Program for Demonstrating Class Level Methods
#ClassLevelMethodEx1.py
class Employee:
	@classmethod
	def  getcompanyname(cls): # Class Level Method
		Employee.cname="IBM"
		Employee.addr="HYD"  # Here cname and addr are called Class Level Data members
	
	def  getempdet(self):  # Instance Method
		self.eno=int(input("Enter Employee Number:"))
		self.ename=input("Enter Employee Name:")
	def dispempdet(self): # Instance Method
		print("Employee Number:{}".format(self.eno))
		print("Employee Name:{}".format(self.ename))
		print("EMP Comp NAME:",Employee.cname)
		print("EMP Comp ADDR:",Employee.addr)


#main program
Employee.getcompanyname() # calling Class Level method w.r.t Class Name
e1=Employee()
e1.getempdet()
e1.dispempdet()