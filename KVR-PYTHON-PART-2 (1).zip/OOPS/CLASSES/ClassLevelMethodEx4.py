#Program for Demonstrating Class Level Methods
#ClassLevelMethodEx4.py
class Employee:
	@classmethod
	def  getcompanyname(cls): # Class Level Method
		cls.cname="IBM" # Here cname is  called Class Level Data members
		cls.getaddr()#calling Class Level method w.r.t Cls
	@classmethod
	def getaddr(cls):	
		cls.addr="HYD"   # Here addr is  called Class Level Data members
	
	def  getempdet(self):  # Instance Method
		self.eno=int(input("Enter Employee Number:"))
		self.ename=input("Enter Employee Name:")
	def dispempdet(self): # Instance Method
		self.getcompanyname() # calling Class Level method w.r.t self
		print("Employee Number:{}".format(self.eno))
		print("Employee Name:{}".format(self.ename))
		print("EMP Comp NAME:",Employee.cname)
		print("EMP Comp ADDR:",Employee.addr)


#main program
e1=Employee() 
e1.getempdet()
e1.dispempdet()
print("-------------------------------------------------------")
e2=Employee() 
e2.getempdet()
e2.dispempdet()
