#StudentPickMenu.py--File Name and Module Name
class Menu:
	def menu(self):
		print("-------------------------------------------------------")
		print("\tStudent Operations")
		print("-------------------------------------------------------")
		print("\t1. Student Pickle Operation")
		print("\t2. Student UnPickle Operation")
		print("\t3. Exit")
		print("-------------------------------------------------------")