#Program for Demonstrating Static Method
#StaticMethodEx5.py
class Student:
	def getstuddata(self):
		self.sno=int(input("Enter Student Number:"))
		self.sname=input("Enter Student Name:")
		self.marks=float(input("Enter Student Marks:"))

class Employee:
	def getempdata(self):
		self.eno=int(input("Enter Employee Number:"))
		self.ename=input("Enter Employee Name:")

class Teacher:
	def getteacherdet(self):
		self.tno=int(input("Enter Teacher ID:"))
		self.tname=input("Enter Teacher Name:")
		self.subject=input("Enter Teacher Subject:")
		self.epr=int(input("Enter Teacher Experience:"))

class Hyd:
	@staticmethod
	def  dispobjdata( obj,objinfo):
		print("---------------------------------------------")
		print("Information abount:{}".format(objinfo))
		print("---------------------------------------------")
		for k,v in obj.__dict__.items():
			print("\t{}--->{}".format(k,v))
		print("---------------------------------------------")
	@classmethod
	def  getinformation(cls,obj,objinfo):
		Hyd.dispobjdata(obj,objinfo) # Calling Static Method From Class Level Method w.r.t cls



#main program
s=Student()
e=Employee()
t=Teacher()
print("-----------------------------------------------")
s.getstuddata()
print("-----------------------------------------------")
e.getempdata()
print("-----------------------------------------------")
t.getteacherdet()
print("-----------------------------------------------")
Hyd.getinformation(s,"Student") # calling Class Level Method w.r.t class name by passing any class object
Hyd.getinformation(e,"Employee")# calling Class Level  Methodw.r.t class name by passing any class object
Hyd.getinformation(t,"Teacher")# calling Class Level Method w.r.t class name by passing any class object


	