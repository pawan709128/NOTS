#program for Demonstrating Instance Methods
#InstanceMethodEx3.py
class Student:
	def getstuddata(self): # Instance Method
		self.sno=int(input("Enter Student Number:"))
		self.sname=input("Enter Student Name:")
		self.marks=float(input("Enter Student Marks:"))
		self.dispstuddata() # calling Instance Method by using self

	def dispstuddata(self):
		print("Student Number:{}".format(self.sno))
		print("Student Name:{}".format(self.sname))
		print("Student Marks:{}".format(self.marks))


#main program
s1=Student()
s2=Student()
#read the Instance data to Object s1
print("-------------------------------------------------------")
s1.getstuddata() # Calling Instance Method w.r.t Object Name
print("-------------------------------------------------------")
s2.getstuddata() # Calling Instance Method w.r.t Object Name
print("-----------------------------")

