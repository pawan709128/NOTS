#Program for Demonstrating Static Method
#StaticMethodEx3.py
class Student:
	def getstuddata(self):
		self.sno=int(input("Enter Student Number:"))
		self.sname=input("Enter Student Name:")
		self.marks=float(input("Enter Student Marks:"))

class Employee:
	def getempdata(self):
		self.eno=int(input("Enter Employee Number:"))
		self.ename=input("Enter Employee Name:")

class Teacher:
	def getteacherdet(self):
		self.tno=int(input("Enter Teacher ID:"))
		self.tname=input("Enter Teacher Name:")
		self.subject=input("Enter Teacher Subject:")
		self.epr=int(input("Enter Teacher Experience:"))

class Hyd:
	@staticmethod
	def  dispobjdata( obj,objinfo):
		print("---------------------------------------------")
		print("Information abount:{}".format(objinfo))
		print("---------------------------------------------")
		for k,v in obj.__dict__.items():
			print("\t{}--->{}".format(k,v))
		print("---------------------------------------------")


#main program
s=Student()
e=Employee()
t=Teacher()
print("-----------------------------------------------")
s.getstuddata()
print("-----------------------------------------------")
e.getempdata()
print("-----------------------------------------------")
t.getteacherdet()
print("-----------------------------------------------")
h=Hyd()
h.dispobjdata(s,"Student") # calling Static Method w.r.t object name by passing any class object
h.dispobjdata(e,"Employee")# calling Static Method w.r.t object name by passing any class object
h.dispobjdata(t,"Teacher")# calling Static Method w.r.t object name by passing any class object


	