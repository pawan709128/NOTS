#University.py----File Name and Module Name
class Univ:
	def getunivdet(self):
		self.uname=input("Enter University name:")
		self.uloc=input("Enter University Location:")
	def dispunivdet(self):
		print("-----------------------------------------------------------")
		print("\tUniversity Details")
		print("-----------------------------------------------------------")
		print("\tUniversity Name:{}".format(self.uname))
		print("\tUniversity Location:{}".format(self.uloc))
		print("-----------------------------------------------------------")