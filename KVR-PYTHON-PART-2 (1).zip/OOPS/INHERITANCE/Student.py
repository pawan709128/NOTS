#Student.py----File name and module name
from College import College
class Student(College):
	def getstuddet(self):
		self.sno=int(input("Enter Student Number:"))
		self.sname=input("Enter Student name:")
		self.crs=input("Enter Student Course:")
		self.getcolldet()
		self.getunivdet()
	def dispstuddet(self):
		self.dispunivdet()
		self.dispcolldet()
		print("-----------------------------------------------------------")
		print("\tStudent Details")
		print("-----------------------------------------------------------")
		print("\tStudent Number:{}".format(self.sno))
		print("\tStudent Name:{}".format(self.sname))
		print("\tStudent Course:{}".format(self.crs))
		print("-----------------------------------------------------------")