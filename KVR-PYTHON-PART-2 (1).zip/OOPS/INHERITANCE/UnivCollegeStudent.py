#UnivCollegeStudent.py
from Student import Student 
so=Student()
so.getstuddet()
so.dispstuddet()