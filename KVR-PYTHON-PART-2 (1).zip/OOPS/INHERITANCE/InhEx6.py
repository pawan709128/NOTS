#InhEx6.py
class Univ:
	def getunivdet(self):
		self.uname=input("Enter University name:")
		self.uloc=input("Enter University Location:")
	def dispunivdet(self):
		print("-----------------------------------------------------------")
		print("\tUniversity Details")
		print("-----------------------------------------------------------")
		print("\tUniversity Name:{}".format(self.uname))
		print("\tUniversity Location:{}".format(self.uloc))
		print("-----------------------------------------------------------")
class College(Univ):
	def getcolldet(self):
		self.cname=input("Enter College name:")
		self.cloc=input("Enter College Location:")
	def dispcolldet(self):
		print("-----------------------------------------------------------")
		print("\tCollege Details")
		print("-----------------------------------------------------------")
		print("\tCollege Name:{}".format(self.cname))
		print("\tCollege Location:{}".format(self.cloc))
		print("-----------------------------------------------------------")
class Student(College):
	def getstuddet(self):
		self.sno=int(input("Enter Student Number:"))
		self.sname=input("Enter Student name:")
		self.crs=input("Enter Student Course:")
	def dispstuddet(self):
		print("-----------------------------------------------------------")
		print("\tStudent Details")
		print("-----------------------------------------------------------")
		print("\tStudent Number:{}".format(self.sno))
		print("\tStudent Name:{}".format(self.sname))
		print("\tStudent Course:{}".format(self.crs))
		print("-----------------------------------------------------------")

#main program
so=Student()
so.getstuddet()
so.getcolldet()
so.getunivdet()
so.dispunivdet()
so.dispcolldet()
so.dispstuddet()
