#College.py----File and Module Name
from University import Univ
class College(Univ):
	def getcolldet(self):
		self.cname=input("Enter College name:")
		self.cloc=input("Enter College Location:")
	def dispcolldet(self):
		print("-----------------------------------------------------------")
		print("\tCollege Details")
		print("-----------------------------------------------------------")
		print("\tCollege Name:{}".format(self.cname))
		print("\tCollege Location:{}".format(self.cloc))
		print("-----------------------------------------------------------")