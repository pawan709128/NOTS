#Program for Demonstating Continue statement
#ContinueEx4.py
s="PYTHON"
#Want to display PTON
i=0
while(i<len(s)):
    if(s[i] in ["Y","H"]):
        i = i + 1
        continue
    else:
        print("\t{}".format(s[i]))
        i=i+1
else:
    print("i am from else of while loop")
print("Program execution Completed")
