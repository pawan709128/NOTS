#Program for Demonstating Continue statement
#ContinueEx2.py
s="PYTHON"
#Display all the letter of s--Part-1
i=0
while(i<len(s)):
    print("\t{}".format(s[i]))
    i=i+1
else:
    print("i am from else of while loop")
print("Program execution Completed")
print("-------------------------------------")
#Want to display PYHON
i=0
while(i<len(s)):
    if(s[i]=="T"):
        i = i + 1
        continue

    else:
        print("\t{}".format(s[i]))
        i=i+1
else:
    print("i am from else of while loop")
print("Program execution Completed")