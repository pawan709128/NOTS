#Program for Demonstating Continue statement
#ContinueEx1.py
s="PYTHON"
#Display all the letter of s--Part-1
for ch in s:
    print("\t{}".format(ch))
else:
    print("i am from else of for loop")
print("Program execution Completed")
print("-------------------------------------")
#Want to display PYHON
for ch in s:
    if(ch=="T"):
        continue
    print(ch)
else:
    print("i am from else of for loop")
print("Program execution Completed")