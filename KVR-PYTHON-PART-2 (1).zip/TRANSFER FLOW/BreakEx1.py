#program for Demonstrating Break statement
#BreakEx1.py
s="PYTHON"
#Display all the letter of s--Part-1
for ch in s:
    print("\t{}".format(ch))
else:
    print("i am from else of for loop")
print("Program execution Completed")
print("-------------------------------------")
#want to display PYT without using slicing and indexing-Part-2
for ch in s:
    if(ch=="H"):
        break
    else:
        print("\t{}".format(ch))
else:
    print("i am from else of for loop")
print("Program execution Completed")