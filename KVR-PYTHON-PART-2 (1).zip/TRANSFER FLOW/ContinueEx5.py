#ContinueEx5.py
lst=[10,-34,56,-23,0,-2,45,67,-56,12]
print("--------------------------------")
print("Given Numbers:{}".format(lst))
print("--------------------------------")
print("List of +Ve values")
print("--------------------------------")
for val in lst:
    if(val<=0):
        continue
    print("\t{}".format(val))
print("--------------------------------")