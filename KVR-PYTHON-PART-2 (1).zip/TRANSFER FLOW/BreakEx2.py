#program for Demonstrating Break statement
#BreakEx2.py
s="PYTHON"
#Display all the letter of s--Part-1
i=0
while(i<len(s)):
    print("\t{}".format(s[i]))
    i=i+1
else:
    print("i am from else part of while")
print("Program execution completed")
print("-------------------------------------")
#want to display PYT without using slicing and indexing-Part-2
i=0
while(i<len(s)):
    if(s[i]=="H"):
        break
    else:
        print("\t{}".format(s[i]))
        i=i+1
else:
    print("i am from else part of while")
print("Program execution completed")
