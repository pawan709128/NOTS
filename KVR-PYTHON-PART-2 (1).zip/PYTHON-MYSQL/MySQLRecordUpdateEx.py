#MySQLRecordUpdateEx.py
import mysql.connector
def recordupdate():
    try:
       con = mysql.connector.connect(host="127.0.0.1",
                                          user="root",
                                          passwd="root",
                                          database="batch6pm")
       while(True):
           try:
               cur=con.cursor()
               print("-"*50)
               #accept the emp number from KBD
               empno=int(input("Enter Employee Number for updating records:"))
               empname=input("Enter Employee Name:")
               empsal =float(input("Enter Employee New Salary:"))
               empdsg = input("Enter Employee Designation:")
               #Prepare the Query with dynamic values
               uq="update employee set ename='%s',sal=%f,dsg='%s' where eno=%d"
               cur.execute(uq %(empname,empsal,empdsg,empno))
               con.commit()
               print("-" * 50)
               if(cur.rowcount>0):
                   print("{} Employee Record Updated Sucessfully in Employee Table".format(cur.rowcount))
               else:
                   print("Employee Record does not exist")
               print("-" * 50)
               ch=input("Do u want update another record(yes/no):")
               if(ch.lower()=="no"):
                   break
           except ValueError:
               print("Don't enter alnums,strs and symbols for empnos")
    except mysql.connector.DatabaseError as db:
            print("Problem in Oarcle DB",db)
#main program
recordupdate()