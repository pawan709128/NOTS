#MySQLTableCreateEx.py
import mysql.connector
def tablecreate():
    try:
        con=mysql.connector.connect(host="127.0.0.1",
                                    user="root",
                                    passwd="root",
                                    database="batch6pm")
        cur=con.cursor()
        tc="create table student(sno int primary key,name varchar(10) not null,marks float not null)"
        cur.execute(tc)
        print("Student Table Created Sucessfully-Verify")
    except mysql.connector.DatabaseError as db:
        print("Problem in MySQL DB:",db)

#main program
tablecreate()