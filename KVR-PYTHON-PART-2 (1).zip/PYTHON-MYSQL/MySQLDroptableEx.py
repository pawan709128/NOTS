#MySQLDroptableEx.py
import mysql.connector
def tablecreate():
    try:
        con=mysql.connector.connect(host="127.0.0.1",
                                    user="root",
                                    passwd="root",
                                    database="batch6pm")
        cur=con.cursor()
        dq="drop table student"
        cur.execute(dq)
        print("Student Table Droped Sucessfully-Verify")
    except mysql.connector.DatabaseError as db:
        print("Problem in MySQL DB:",db)

#main program
tablecreate()