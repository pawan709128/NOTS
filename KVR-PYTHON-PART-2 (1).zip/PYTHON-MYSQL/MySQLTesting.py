import mysql.connector
print(mysql.connector.__version__)