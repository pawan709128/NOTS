#Program for demonstrating Connection from MYSQL
#MySQLConnTestEx1.py
import mysql.connector
con=mysql.connector.connect(host="localhost",
                            user="root",
                            passwd="root")
print("\nPython Program obtains Connection from MySQL")
print("Type of con=",type(con))