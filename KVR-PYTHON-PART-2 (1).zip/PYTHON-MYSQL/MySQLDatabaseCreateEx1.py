#Program for Creating a Database--batch6pm
#MySQLDatabaseCreateEx1.py
import mysql.connector
def databasecreate():
    try:
        con=mysql.connector.connect(host="127.0.0.1",
                                    user="root",
                                    passwd="root")
        cur=con.cursor()
        dc="create database batch6pm"
        cur.execute(dc)
        print("Database Created Sucessfully-Verify")
    except mysql.connector.DatabaseError as db:
        print("Problem in MySQL DB:",db)

#main program
databasecreate()