#MySQLRecordSelectEx.py
import mysql.connector
def recordsselect():
    try:
       con = mysql.connector.connect(host="127.0.0.1",
                                          user="root",
                                          passwd="root",
                                          database="batch6pm")
       cur=con.cursor()
       tname=input("Enter any table Name:")
       cur.execute("select * from %s" %tname)
       #getting Col names
       print("-"*40)
       for col in cur.description:
           print("{}".format(col[0]),end="\t")
       print()
       print("-" * 40)
       #getting the records
       records=cur.fetchall()
       for record in records:
           for val in record:
               print("{}".format(val),end="\t")
           print()
       print("-" * 40)

    except mysql.connector.DatabaseError as db:
            print("Problem in Oarcle DB",db)
#main program
recordsselect()