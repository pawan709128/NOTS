#OracleRecordDeleteEx1.py
import cx_Oracle
def deleterecord():
    try:
        con=cx_Oracle.connect("system/manager@127.0.0.1/xe")
        cur=con.cursor()
        empno=int(input("Enter Employee Number for deleting a Record:"))
        cur.execute("delete from employee where eno=%d" %empno)
        con.commit()
        if(cur.rowcount>0):
            print("{} Employee Record Deleted".format(cur.rowcount))
        else:
            print("{} Emp Number Does not Exist".format(empno))
    except cx_Oracle.DatabaseError as db:
        print("Problem in Oarcle DB", db)

#main program
deleterecord()