#OracleRecordUpdateEx1.py
import cx_Oracle
def updaterecord():
    try:
        con=cx_Oracle.connect("system/manager@127.0.0.1/xe")
        cur=con.cursor()
        empno=int(input("Enter Employee Number for Updating a Record:"))
        cname=input("Enter New Company Name of Employee: ")
        cur.execute("update employee set sal=sal+sal*(20/100),cname='%s' where eno=%d" %(cname,empno))
        con.commit()
        if(cur.rowcount>0):
            print("{} Employee Record Updated--Verify".format(cur.rowcount))
        else:
            print("Employee Number Does not Exist")
    except cx_Oracle.DatabaseError as db:
        print("Problem in Oarcle DB", db)

#main program
updaterecord()