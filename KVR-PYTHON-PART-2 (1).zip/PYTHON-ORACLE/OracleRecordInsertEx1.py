#OracleRecordInsertEx1.py
import cx_Oracle
def recordinsert():
    try:
        con=cx_Oracle.connect("system/manager@localhost/xe")
        cur=con.cursor()
        iq="insert into employee values(400,'Sagatika',2.4,'SE')"
        cur.execute(iq)
        con.commit()
        print("Employee Inserted Sucessfully in Employee Table")

    except cx_Oracle.DatabaseError as db:
        print("Problem in Oarcle DB",db)

#main program
recordinsert()