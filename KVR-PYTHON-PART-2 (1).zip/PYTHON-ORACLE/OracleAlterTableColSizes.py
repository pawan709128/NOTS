#OracleAlterTableColSizes.py
import cx_Oracle #Step-1
def tableColSize():
    try:
        con=cx_Oracle.connect("system/manager@localhost/xe")  #Step-2
        cur=con.cursor()  #Step-3
        #step-4
        aq="alter table employee modify(eno number(3),ename varchar2(15))"
        cur.execute(aq)
        #Step-5
        print("Employee Table altered sucessfully in Oracle Database--verify ")
    except cx_Oracle.DatabaseError as db:
        print("Problem in Oarcle DB",db)

#main program
tableColSize()