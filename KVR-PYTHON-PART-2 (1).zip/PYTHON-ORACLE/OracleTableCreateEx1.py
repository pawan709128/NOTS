#OracleTableCreateEx1.py
import cx_Oracle #Step-1
def tablecreate():
    try:
        con=cx_Oracle.connect("system/manager@localhost/xe")  #Step-2
        cur=con.cursor()  #Step-3
        #step-4
        ct="create table employee1(eno number(2) primary key,ename varchar2(10) not null,sal number(5,2) not null)"
        cur.execute(ct)
        #Step-5
        print("Employee Table Created sucessfully in Oracle Database--verify ")
    except cx_Oracle.DatabaseError as db:
        print("Problem in Oarcle DB",db)

#main program
tablecreate()