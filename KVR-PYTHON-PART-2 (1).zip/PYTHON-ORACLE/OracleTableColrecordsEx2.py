#Program for obtaining Col names along with records
#OracleTableColrecordsEx1.py
import cx_Oracle
def getrecords():
    try:
        con = cx_Oracle.connect("system/manager@127.0.0.1/xe")
        cur = con.cursor()
        cur.execute("select * from employee")
        print("-----------------------------")
        #Code obtaining Col Names
        for col in cur.description:
            print(col[0],end="\t")
        print()
        print("-----------------------------")
        # Code obtaining Records
        records=cur.fetchall()
        for record in records:
            for val in record:
                print("{}".format(val),end="\t")
            print()
        print("-----------------------------")
    except cx_Oracle.DatabaseError as db:
        print("Problem in Oracle DB:", db)

#main program
getrecords()