#OracleRecordUpdateEx2.py
import cx_Oracle
def updaterecord():
    while(True):
        try:
            con=cx_Oracle.connect("system/manager@127.0.0.1/xe")
            cur=con.cursor()
            empno = int(input("Enter Employee Number for Updating a Record:"))
            cname = input("Enter New Company Name of Employee: ")
            empsal=float(input("Enter New Sal of Employee "))
            cur.execute("update employee set sal=%f,cname='%s' where eno=%d" %(empsal,cname, empno))
            con.commit()
            if(cur.rowcount>0):
                print("{} Employee Record Updated".format(cur.rowcount))
            else:
                print("{} Emp Number Does not Exist".format(empno))
            print("--------------------------------------")
            ch = input("Do u want Update  another record(yes/no):")
            if (ch.lower() == "no"):
                break
        except cx_Oracle.DatabaseError as db:
            print("Problem in Oarcle DB", db)
        except ValueError:
            print("Don't enter alnums,strs and symbols for empnos,sals")


#main program
updaterecord()