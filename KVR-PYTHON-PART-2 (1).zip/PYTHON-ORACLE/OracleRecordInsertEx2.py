#OracleRecordInsertEx2.py
import cx_Oracle
def recordinsert():
    try:
        con=cx_Oracle.connect("system/manager@localhost/xe")
        cur=con.cursor()
        #accept the emp details from KBD
        empno=int(input("Enter Employee Number:"))
        empname=input("Enter Employee Name:")
        empsal=float(input("Enter Employee Salary:"))
        empdsg = input("Enter Employee Designation:")
        #Prepare the Query with dynamic values
        iq="insert into employee values(%d,'%s',%f,'%s')"
        cur.execute(iq %(empno,empname,empsal,empdsg))
        #OR cur.execute("insert into employee values(%d,%s',%f,'%s')" %(empno,empname,empsal,empdsg))
        con.commit()
        print("Employee Inserted Sucessfully in Employee Table")
    except cx_Oracle.DatabaseError as db:
        print("Problem in Oarcle DB",db)

#main program
recordinsert()