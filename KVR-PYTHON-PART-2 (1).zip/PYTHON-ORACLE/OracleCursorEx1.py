#Program for creating an object of cursor
#OracleCursorEx1.py
import cx_Oracle # Step-1
try:
	con=cx_Oracle.connect("system/manager@localhost/xe") #Step-2
	print("\nPython Program Obtains Connection from Oracle DB")
	cur=con.cursor() #Step-3
	print("\nType of cur=",type(cur))
	print("Python Program creates Cursor object")
except cx_Oracle.DatabaseError as db:
	print("Problem in Oracle DB:",db)
