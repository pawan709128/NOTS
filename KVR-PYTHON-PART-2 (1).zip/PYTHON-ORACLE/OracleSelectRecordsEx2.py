#Program for Reading the records from employee table--fetchmany()
#OracleSelectRecordsEx2.py
import cx_Oracle
def getrecords():
    try:
        con = cx_Oracle.connect("system/manager@127.0.0.1/xe")
        cur = con.cursor()
        cur.execute("select * from employee")
        records=cur.fetchmany(4)
        print("-----------------------------")
        for record in records:
            for val in record:
                print("{}".format(val),end="\t")
            print()
        print("-----------------------------")
    except cx_Oracle.DatabaseError as db:
        print("Problem in Oracle DB:", db)

#main program
getrecords()