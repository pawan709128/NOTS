#Program for Reading the records from employee table--fetchone()
#OracleSelectRecordsEx1.py
import cx_Oracle
def getrecords():
    try:
        con=cx_Oracle.connect("system/manager@127.0.0.1/xe")
        cur=con.cursor()
        cur.execute("select * from employee")
        print("------------------------------------")
        while(True):
            record = cur.fetchone()
            if(record!=None):
                for val in record:
                    print("{}".format(val),end="\t")
                print()
            else:
                print("------------------------------------")
                break
    except cx_Oracle.DatabaseError as db:
        print("Problem in Oracle DB:",db)

#main program
getrecords()