#Program for demonstrating Relational Operators
#RelOpEx1.py
a=int(input("Enter Value of a:"))
b=int(input("Enter Value of b:"))
print("="*50)
print("Reuslts of Relational Operators")
print("="*50)
print("\t\t{} > {}={}".format(a,b,a>b)) # here a>b is called Rel Expr
print("\t\t{} < {}={}".format(a,b,a<b))
print("\t\t{} == {}={}".format(a,b,a==b))
print("\t\t{} != {}={}".format(a,b,a!=b))
print("\t\t{} >= {}={}".format(a,b,a>=b))
print("\t\t{} <= {}={}".format(a,b,a<=b))
print("="*50)