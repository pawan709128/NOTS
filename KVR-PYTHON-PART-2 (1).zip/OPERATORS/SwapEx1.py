#Program for Swapping of Two values
#SwapEx1.py
a=input("Enter Value of a:")
b=input("Enter Value of b:")
print("-"*50)
print("\nOriginal Value of a:{}".format(a))
print("Original Value of b:{}".format(b))
print("-"*50)
a,b=b,a # Multi line assignment
print("\nSwapped Value of a:{}".format(a))
print("Swapped Value of b:{}".format(b))
print("-"*50)
