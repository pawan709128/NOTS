#Program for cal square root of a given number
#ArithmeticOpEx2.py
n=int(input("Enter a number for cal Square Root:"))
res=n**0.5
print("sqrt({})={}".format(n,res))
print("===========OR==============")
res=n**(1/2)
print("sqrt({})={}".format(n,res))