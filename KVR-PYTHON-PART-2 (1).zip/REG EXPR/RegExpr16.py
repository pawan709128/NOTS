#Program for serching  all   except Alphabets
#RegExpr16.py
import re
mattab=re.finditer("[^A-Za-z]","!cAK@2aLp4#Gq8HbQw")
print("-------------------------------------------")
for mat in mattab:
	print("Start Index:{}  End Index:{} Value:{}".format(mat.start(),mat.end(),mat.group()))
print("-------------------------------------------")

"""

D:\KVR-PYTHON-6PM\REG EXPR>py RegExpr16.py
-------------------------------------------
Start Index:0  End Index:1 Value:!
Start Index:4  End Index:5 Value:@
Start Index:5  End Index:6 Value:2
Start Index:9  End Index:10 Value:4
Start Index:10  End Index:11 Value:#
Start Index:13  End Index:14 Value:8
-------------------------------------------
"""