#Program for serching  all   Digits
#RegExpr11.py
import re
mattab=re.finditer("[0-9]","cAK@2aLp4#Gq8HbQw")
print("-------------------------------------------")
for mat in mattab:
	print("Start Index:{}  End Index:{} Value:{}".format(mat.start(),mat.end(),mat.group()))
print("-------------------------------------------")

"""
D:\KVR-PYTHON-6PM\REG EXPR>py RegExpr11.py
-------------------------------------------
Start Index:4  End Index:5 Value:2
Start Index:8  End Index:9 Value:4
Start Index:12  End Index:13 Value:8
-------------------------------------------
"""