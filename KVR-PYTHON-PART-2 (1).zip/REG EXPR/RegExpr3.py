#RegExpr3.py
import re
gd="Python is an oop Lang.Python is also Fun Prog Lang"
sp="Python"
res=re.findall(sp,gd) # res is of type of list
print(" '{}' found {} Time(s)".format(sp,len(res)))