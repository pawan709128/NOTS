#Program for Extracting the names and Marks of the students from given text data
#ExtractNamesMarksEx1.py
import re
gd="Rossum is the developer of python got 56 , Travis is the developer of numpy and got 55 , Kinney   is developer of pandas  and got 33 and Ritche   is the devloper of c lang and got 66"
nameslist=re.findall("[A-Z][a-z]+",gd)
print("Names List")
for name in nameslist:
	print("\t{}".format(name))
markslist=re.findall("\d{2}",gd)
print("Marks List")
for marks in markslist:
	print("\t{}".format(marks))
