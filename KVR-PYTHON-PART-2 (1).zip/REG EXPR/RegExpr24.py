#Program for searching  one k or More K's
#RegExpr24.py
import re
mattab=re.finditer("k+","kvkkvkkkvkv")
print("-------------------------------------------")
for mat in mattab:
	print("Start Index:{}  End Index:{} Value:{}".format(mat.start(),mat.end(),mat.group()))
print("-------------------------------------------")

"""
D:\KVR-PYTHON-6PM\REG EXPR>py RegExpr24.py
-------------------------------------------
Start Index:0  End Index:1 Value:k
Start Index:2  End Index:4 Value:kk
Start Index:5  End Index:8 Value:kkk
Start Index:9  End Index:10 Value:k
-------------------------------------------
"""