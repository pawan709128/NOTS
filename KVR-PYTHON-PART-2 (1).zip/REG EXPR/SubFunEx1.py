#SubFunEx1.py
import re
txt = "The rain in Spain"
x = re.sub("\s", "9", txt)
print(x)