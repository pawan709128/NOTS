#program for extracting the mail from file(empmails.data) by using RegExpr
#ExtractMailsEx1.py
import re
try:
	with open("D:\\KVR-PYTHON-6PM\REG EXPR\\notes\\empmails.data","r") as fp:
		mailsdata=fp.read()
		#Extract  mails only
		#sp=re.compile("\S+@\S+")
		mailslist=re.findall("\S+@\S+",mailsdata)
		nameslist=re.findall("[A-Z][a-z]+",mailsdata)
		print("-----------------------------------------")
		print("\tNames\tMail-Ids")
		print("-----------------------------------------")
		for name,mails in zip(nameslist,mailslist):
			print("\t{}\t{}".format(name,mails))
		print("-----------------------------------------")
except FileNotFoundError:
	print("File does not exist")