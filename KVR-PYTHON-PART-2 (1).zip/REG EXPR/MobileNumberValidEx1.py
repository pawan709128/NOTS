#Program for validating Mobile Number by using Reg Expr
#MobileNumberValidEx1.py
import re
while(True):
	mno=input("Enter Ur Mobile Number:")
	if(len(mno)==10):
		res=re.search("\d{10}",mno)
		if(res!=None):
			print("\t{} is Valid Mobile Number".format(mno))
			break
		else:
			print("\t{} is Invalid bcoz It contains Non-Digits".format(mno))
	else:
		print("\t{} is Invalid Mobile Number due to its invalid length---try again".format(mno))
