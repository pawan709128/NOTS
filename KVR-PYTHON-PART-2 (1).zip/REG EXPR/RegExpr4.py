#RegExpr4.py
import re
gd="Python is an oop Lang.Python is also Fun Prog Lang"
sp="Python"
mattab=re.finditer(sp,gd) # here mattab is object of <class 'callable_iterator'>
for mat in mattab:  # Here mat is an object of <class,re.Match>
	print("start Index:{}  End Index:{}  Value:{}".format(mat.start(),mat.end(),mat.group()))
