#Program for Extracting Student names and Marks where in the information present in File(student.data). by using Regular Expression.
#ExtractStudNamesMarksFilesEx1.py
import re
try:
	with open("D:\\KVR-PYTHON-6PM\REG EXPR\\notes\\studdents.data","r") as fp:
		filedata=fp.read()
		nameslist=re.findall("[A-Z][a-z]+",filedata)
		markslist=re.findall("\d{2}",filedata)
		print("-------------------------------------------")
		print("\tNames\tMarks")
		print("-------------------------------------------")
		for names,marks in zip(nameslist,markslist):
			print("\t{}\t{}".format(names,marks))
		print("-------------------------------------------")
except FileNotFoundError:
	print("File does not exist")