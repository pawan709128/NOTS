#Program for serching  for Space Character
#RegExpr17.py
import re
mattab=re.finditer("\s","!c AK@2a Lp4#Gq8 HbQw")
print("-------------------------------------------")
for mat in mattab:
	print("Start Index:{}  End Index:{} Value:{}".format(mat.start(),mat.end(),mat.group()))
print("-------------------------------------------")

"""
-------------------------------------------

D:\KVR-PYTHON-6PM\REG EXPR>py RegExpr17.py
-------------------------------------------
Start Index:2  End Index:3 Value:
Start Index:8  End Index:9 Value:
Start Index:16  End Index:17 Value:
-------------------------------------------
"""