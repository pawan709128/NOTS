#ReduceFunEx1.py
import functools
def sumop(x,y):
    return (x+y)

#main program
print("Enter List of Values separated by space: ")
lst=[int(val) for val in input().split()]
print("--------------------------------")
print("Given List={}".format(lst))
res=functools.reduce(sumop,lst)
print("sum({})={}".format(lst,res))
print("--------------------------------")
