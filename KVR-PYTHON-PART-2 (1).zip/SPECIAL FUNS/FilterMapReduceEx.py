#FilterMapReduceEx.py
import functools,time
print("Enter List of Employee Salaries Ranges from 0 to 1000:")
sallist=[int(sal) for sal in input().split() if 0<=int(sal)<=1000 ]
print("----------------------------------------------------------")
print("Original Sal List:{}".format(sallist))
print("----------------------------------------------------------")
time.sleep(5)
sal0_500=list(filter(lambda sal:0<=sal<=500, sallist))
sal501_1000=list(filter(lambda sal:501<=sal<=1000, sallist))
print("Sal List between 0 to 500:{}".format(sal0_500))
print("Sal List between 501 to 1000:{}".format(sal501_1000))
print("----------------------------------------------------------")
hikesal0_500=list(map(lambda sal: sal+sal*(10/100),sal0_500))
hikesal501_1000=list(map(lambda sal: sal+sal*(20/100),sal501_1000))
#Find sum of Sals for 0--500
totsal0_500=functools.reduce(lambda sal1,sal2:sal1+sal2,hikesal0_500)
#Find sum of Sals for 501--1000
totsal501_1000=functools.reduce(lambda sal1,sal2:sal1+sal2,hikesal501_1000)
time.sleep(5)
print("----------------------------------------------------------")
print("Old Sal 0-500\tHike 0-500")
print("----------------------------------------------------------")
for osl,nsl in zip(sal0_500,hikesal0_500):
	print("\t{}\t{}".format(osl,nsl))
print("----------------------------------------------------------")
print("TOTAL SALARY FOR 0-500 HIKE:{}".format(totsal0_500))
time.sleep(5)
print("Old Sal 501-1000\tHike 501-1000")
print("----------------------------------------------------------")
for osl,nsl in zip(sal501_1000,hikesal501_1000):
	print("\t{}\t{}".format(osl,nsl))
print("----------------------------------------------------------")
print("TOTAL SALARY FOR 501-1000 HIKE:{}".format(totsal501_1000))
print("="*60)
time.sleep(5)
print("TOTAL SALARY PAID THE COMPANY TO ALL EMPLOYEES={}".format(totsal0_500+totsal501_1000))
print("="*60)