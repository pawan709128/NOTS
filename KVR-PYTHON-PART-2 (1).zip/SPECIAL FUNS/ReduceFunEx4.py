#ReduceFunEx4.py
import functools
print("Enter List of words separated by comma: ")
lst=[word for word in input().split(",")]
print("--------------------------------")
print("Given Words={}".format(lst))
print("--------------------------------")
line=functools.reduce(lambda a,b:a+" "+b,lst)
print("Line:{}".format(line))
print("--------------------------------")