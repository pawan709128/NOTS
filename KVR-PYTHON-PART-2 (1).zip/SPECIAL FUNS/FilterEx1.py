#Program for demonstarting filter()
#FilterEx1.py
def posvalue(n):
	if(n>0):
		return True
	else:
		return False


#main program
lst=[10,23,-45,67,-68,-78,12,-34,28]
kvr=filter(posvalue,lst)
print("Type of kvr=",type(kvr)) # <class 'filter'>
#convert filter object into list type, tuple,set type
pslist=list(kvr)
print("Given List=",lst)
print("Possitive Elements List=",pslist)