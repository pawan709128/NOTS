#Program for demonstarting filter()
#FilterEx6.py
print("Enter List of Values Separated by Space:")
lst=[int(val) for val in input().split()]
evenlist=list(filter(lambda n: n%2==0,lst))
oddlist=list(filter(lambda n:n%2!=0,lst))
print("----------------------------------------------")
print("Given List:{}".format(lst))
print("Even List:{}".format(evenlist))
print("Odd List:{}".format(oddlist))
print("----------------------------------------------")
