#Program for demonstrating map()
#MapEx1.py
def  hike(sal):
	return(sal+sal*(50/100))

#main program
oldsal=[10,15,5,20,30,16]
obj=map(hike,oldsal)
print("Type of obj=",type(obj)) # <class 'map'>
print("---------------------------------------------")
#convert map object into list object
newsal=list(obj)
print("Old Salary List:{}".format(oldsal))
print("New Salary List:{}".format(newsal))
print("---------------------------------------------")

