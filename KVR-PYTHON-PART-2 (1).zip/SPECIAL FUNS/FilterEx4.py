#Program for demonstarting filter()
#FilterEx4.py

posvalue=lambda n: n>0 # Anonymous Function

#main program
print("Enter List of Values Separated by Space:")
lst=[int(val) for val in input().split()]
pslist=tuple(filter(posvalue,lst))
print("Given List=",lst)
print("Possitive Elements List=",pslist)