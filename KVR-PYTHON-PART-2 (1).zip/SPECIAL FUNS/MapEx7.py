#Program for demonstrating map()
#MapEx7.py

def  listsum(x,y):
	return (x+y)


#main program
print("Enter List of values for First List:")
lst1=[int(val) for val in input().split()]
print("Enter List of values for Second List:")
lst2=[int(val) for val in input().split()]
lst3=list(map(listsum,lst1,lst2))
print("{}+{}={}".format(lst1,lst2,lst3))