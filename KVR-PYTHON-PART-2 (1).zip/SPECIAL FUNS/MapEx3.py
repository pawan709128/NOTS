#Program for demonstrating map()
#MapEx3.py

hike=lambda sal:sal+sal*(50/100) # Anonymous Function
#main program
print("Enter list of salaries of employees:")
oldsallist=[int(val) for val in input().split()]
oldsal=list(filter(lambda sal:sal>0,oldsallist))
newsal=list(map(hike,oldsal))
print("---------------------------------------------")
print("Old Salary List:{}".format(oldsal))
print("New Salary List:{}".format(newsal))
print("---------------------------------------------")

