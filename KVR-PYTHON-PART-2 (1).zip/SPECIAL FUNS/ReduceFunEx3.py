#ReduceFunEx3.py
import functools
print("Enter List of Values separated by space: ")
lst=[int(val) for val in input().split()] #[10,30,20,40]
print("--------------------------------")
bigv=functools.reduce(lambda x,y: x if x>y else y, lst)
smallv=functools.reduce(lambda x,y: x if x<y else y,lst)
print("big({})={}".format(lst,bigv))
print("small({})={}".format(lst,smallv))
