#Program for demonstrating map()
#MapEx2.py
def  hike(sal):
	return(sal+sal*(50/100))

#main program
oldsal=[10,15,5,20,30,16]
newsal=list(map(hike,oldsal))
print("---------------------------------------------")
print("Old Salary List:{}".format(oldsal))
print("New Salary List:{}".format(newsal))
print("---------------------------------------------")

