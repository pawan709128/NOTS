#SimpleIntFunEx1.py
def simpleint():
    print("---------------------------")
    p=float(input("Enter Principle Amount: "))
    t=float(input("Enter Time: "))
    r=float(input("Enter Rate of Interest:"))
    print("---------------------------")
    #cal si
    si=(p*t*r)/100
    #cal totamt
    totamt=p+si
    return p,t,r,si,totamt
#main program
result=simpleint() # here result is of type tuple
print("======================================")
print("\t\tSimple Intrest Results")
print("======================================")
print("\tPrinciple Amount:{}".format(result[0]))
print("\tTime:{}".format(result[1]))
print("\tRateInterest:{}".format(result[2]))
print("\tSimple Interest:{}".format(result[3]))
print("\tTotal Amount to pay:{}".format(result[4]))
print("======================================")


