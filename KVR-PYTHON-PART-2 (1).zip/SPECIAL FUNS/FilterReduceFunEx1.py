#FilterReduceFunEx1.py
import functools
print("Enter List of Values separated by Space: ")
lst=[int(val) for val in input().split()]
print("--------------------------------")
print("Given Values={}".format(lst))
print("--------------------------------")
#Filter +Ve values
poslist=list(filter(lambda n:n>0,lst))
#Filter -Ve values
neglist=list(filter(lambda n:n<0,lst))
print("Given Possitive List={}".format(poslist))
print("Given Negative List={}".format(neglist))
print("--------------------------------")
#Find sum of Possitive Elements List
pslistsum=functools.reduce(lambda x,y: x+y,poslist)
nglistsum=functools.reduce(lambda x,y: x+y,neglist)
print("PossitiveSum({})={}".format(poslist,pslistsum))
print("NegativeSum({})={}".format(neglist,nglistsum))
print("--------------------------------")