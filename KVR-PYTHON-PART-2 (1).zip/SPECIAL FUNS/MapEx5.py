#Program for demonstrating map()
#MapEx5.py
print("Enter List of Words separated by space:")
words=[word for word in input().split()]
print("-----------------------------------------------------------")
print("Given Words=",words)
print("-----------------------------------------------------------")
rwords=list(map(lambda word:word[::-1],words))
print("Reversed Words=",rwords)