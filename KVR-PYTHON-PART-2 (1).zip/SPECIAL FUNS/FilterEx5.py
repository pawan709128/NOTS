#Program for demonstarting filter()
#FilterEx5.py
print("Enter List of Values Separated by Space:")
lst=[int(val) for val in input().split()]
pslist=tuple(filter(lambda n:n>0 , lst))
nglist=set(filter(lambda n:n<0 , lst))
print("---------------------------------------------------")
print("Given List=",lst)
print("Possitive Elements List=",pslist)
print("Negative Elements=",nglist)
print("---------------------------------------------------")