#Program for demonstrating map()
#MapEx6.py
line=input("Enter Line of text:")
words=line.split()
print("-----------------------------------------------------------")
print("Given Words=",words)
print("-----------------------------------------------------------")
rwords=list(map(lambda word:word[::-1],words))
print("Reversed Words=",rwords)