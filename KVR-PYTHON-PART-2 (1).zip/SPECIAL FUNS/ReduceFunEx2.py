#ReduceFunEx2.py
import functools
print("Enter List of Values separated by space: ")
lst=[int(val) for val in input().split()]
print("--------------------------------")
print("Given List={}".format(lst))
res=functools.reduce(lambda x,y:x+y,lst)
print("sum({})={}".format(lst,res))
print("--------------------------------")