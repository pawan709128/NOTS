#Program for generating 1 to n numbers after each and every second
#NumGenFunEx2.py
import threading,time
def generate():
	print("Name of the threading generate()=",threading.current_thread().name)
	n=int(input("\nEnter How Many Numbers u want to generate:"))
	if(n<=0):
		print("{} Invalid Input".format(n))
	else:
		print("---------------------------------------------")
		print("Numbers within:{}".format(n))
		print("---------------------------------------------")
		for i in range(1,n+1):
			print("\tValue of i={}".format(i))
			time.sleep(1)
		print("---------------------------------------------")

#main program
t1=threading.Thread(target=generate) # Sub thread creation
t1.start()