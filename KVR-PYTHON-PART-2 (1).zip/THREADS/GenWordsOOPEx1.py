#program for accepting a line of text and display the words  by using threads
#GenWordsOOPEx1.py
import threading,time
class Words:
	def __init__(self):
		self.line=input("Enter a Line of Text:")

	def getwords(self):
		words=self.line.split()
		for word in words:
			print("\t{}".format(word))
			for ch in word:
				print("\t\t{}".format(ch))
				time.sleep(0.5)
			time.sleep(0.25)

#main program
t1=threading.Thread(target=Words().getwords)
t1.start()
