#Program for creating sub thread, set name and get name of the threads,execution status and join
#SubThreadExecStatusEx1.py
import threading,time
def   welcome(val):
	print("----------------------------------------------")
	print("Name of the sub thread in welcome()=",threading.current_thread().name)
	time.sleep(10)
	print("{} Good Evening".format(val))
	print("----------------------------------------------")

#main program
#create sub thread
print("Name of main thread=",threading.current_thread().name)
print("-----------------------------------------------------------------------")
print("Number of Threads in this program before sub threads=",threading.active_count())
t1=threading.Thread(target=welcome,args=("Rossum",))
print("Execution status of sub thread before start=",t1.is_alive()) # False
#dispatch or send the sub thread to targetted Function
t1.start()
print("Execution status of sub thread after start=",t1.is_alive()) # True
print("Number of Threads in this program during execution=",threading.active_count())
t1.join()
print("Number of Threads in this program after sub threads completion=",threading.active_count())
print("Execution status of sub thread after completion=",t1.is_alive()) # False
print("----------------------------------------------------------------------")