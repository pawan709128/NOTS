#Program for finding number of threads in program
#ActiveCountEx.py
import threading
print("Default Name of therad=",threading.current_thread().name)
print("By Default ,Number of threads active=",threading.active_count())