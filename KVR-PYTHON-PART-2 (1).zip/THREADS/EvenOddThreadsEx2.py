#Program for generating Even and Odd Numbers  separately by two threads
#EvenOddThreadsEx2.py
import threading , time
class Numbers:
	def  oddnums(self,n):
		if(n<=0):
			print("{}--->{} is Invalid Input".format(threading.current_thread().name,n))
		else:
			for i in range(1,n+1,2):
				print("{}---Odd Number:{}".format(threading.current_thread().name,i))
				time.sleep(1)

	def  evennums(self,n):
		if(n<=0):
			print("{}--->{} is Invalid Input".format(threading.current_thread().name,n))
		else:
			for i in range(2,n+1,2):
				print("{}--Even Number:{}".format(threading.current_thread().name,i))
				time.sleep(1)

#main program
#create sub threads
t1=threading.Thread(target=Numbers().oddnums,args=(int(input("Enter How many Odd Numbers u want Generate: ")),))
t2=threading.Thread(target=Numbers().evennums,args=(int(input("Enter How many Even Numbers u want Generate: ")),))
#dispatch the sub threads
t1.start()
t2.start()