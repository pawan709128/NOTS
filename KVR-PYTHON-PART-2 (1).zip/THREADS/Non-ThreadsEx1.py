#Program for demonstraing non-thread based applications (Contains only MainThread But not Sub Threads)
#Non-ThreadsEx1.py
import threading
def  hello():
	print("Line-5:hello() executed by {}".format(threading.current_thread().name))

def  hi():
	print("Line:8: hi() executed by {}".format(threading.current_thread().name))

def  welcome():
	print("Line 11: welcome() executed by {}".format(threading.current_thread().name))

#main program
print("Line 14: Program Execution started by :{}".format(threading.current_thread().name))
print("Number of threads in this program=",threading.active_count())
print("----------------------------------------------------------------")
hello()
print("Line:17")
hi()
print("Line:19")
welcome()
print("----------------------------------------------------------------")
print("Line-22:Program Execution started by :{}".format(threading.current_thread().name))
