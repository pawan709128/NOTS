#Program for obtaining Default Thread (MainThread)
#CurrentThreadEx1.py
import threading 
t=threading.current_thread()
#tname=t.getName()----Not Recommended  bcoz getName() is deprecated on the name of 'name' attribute
tname=t.name
print("Default thread Name=",tname)
print("==========OR===============")
tname=threading.current_thread().name
print("Default thread Name=",tname)