#Program for Reserving a seat by using threading--
#SyncReservationFunEx1.py
import threading,time
def  reservation(nos):
	K.acquire()#Step-2
	global totseats
	print("----------------------------------------------------")
	if(nos>totseats):
		print("Dear Passenger {}, {} Seats are Not Available-Try next Day".format(threading.current_thread().name,nos))
		time.sleep(5)
	else:
		totseats=totseats-nos
		print("Dear Passenger {}, {} Seats are Reserved-Happy Journey".format(threading.current_thread().name,nos))
		time.sleep(5)
		print("Now Available Seats in Train:{}".format(totseats))
		print("----------------------------------------------------")
	K.release()#Step-3
#main program
K=threading.Lock() #Step-1
totseats=15
print("TOTAL NUMBER OF SEATS=",totseats)
#Create Sub threads
t1=threading.Thread(target=reservation,args=(5,))
t1.name="Rajesh"
t2=threading.Thread(target=reservation,args=(15,))
t2.name="Naresh"
t3=threading.Thread(target=reservation,args=(6,))
t3.name="Vinay"
t4=threading.Thread(target=reservation,args=(5,))
t4.name="Naveen"
t5=threading.Thread(target=reservation,args=(4,))
t5.name="Rakesh"
#dispatch the threads
t1.start()
t2.start()
t3.start()
t4.start()
t5.start()
