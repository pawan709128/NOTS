#Program for generating 1 to n numbers after each and every second
#NumGenOOPEx4.py
import threading,time
class Numbers:
	def __init__(self,n):
		self.n=n
	def generate(self):
		print("Name of the threading generate()=",threading.current_thread().name)
		if(self.n<=0):
			print("{} Invalid Input".format(self.n))
		else:
			print("---------------------------------------------")
			print("Numbers within:{}".format(self.n))
			print("---------------------------------------------")
			for i in range(1,self.n+1):
				print("\tValue of i={}".format(i))
				time.sleep(0.25)
			print("---------------------------------------------")

#main program
n=int(input("\nEnter How Many Numbers u want to generate:"))
no=Numbers(n) # Object creation calls Paremeterized Constructor
t1=threading.Thread(target=no.generate) # Sub thread creation
t1.start()