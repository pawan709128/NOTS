#Program for creating sub thread, set name and get name of the threads
#SubThreadCreationEx1.py
import threading
def   welcome(val):
	print("----------------------------------------------")
	print("Name of the sub thread in welcome()=",threading.current_thread().name)
	print("{} Good Evening".format(val))
	print("----------------------------------------------")

#main program
#create sub thread
t1=threading.Thread(target=welcome,args=("Rossum",))
print("Name of Sub Thread in main program before setting=",t1.name)
#t1.setName("Rajesh")---Not recommended bcoz setName() is decprecated on "name" attribute
t1.name="Rajesh" #---recommended to use
print("Name of Sub Thread in main program after setting=",t1.name)
#dispatch or send the sub thread to targetted Function
t1.start()