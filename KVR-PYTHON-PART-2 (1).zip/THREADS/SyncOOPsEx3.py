#Program demonstrating Multiple threads enters into same function and avoids Dead Lock / Race Condition
#SyncOOPsEx3.py
import threading,time
class Table:
	@classmethod
	def getLock(cls):
		cls.L=threading.Lock() # Step-1---create an object of Lock class--here L is Class Level data Member
	def __init__(self,n):
		self.n=n
	def  multable(self):
		Table.L.acquire() # Step-2
		if(self.n<=0):
			print("{}--->{} is Invalid input".format(threading.current_thread().name,self.n))
		else:
			print("-"*50)
			print("{}---Mul Table for {}".format(threading.current_thread().name,self.n))
			print("-"*50)
			for i in range(1,11):
				print("\t{} x {} = {}".format(self.n,i,self.n*i))
				time.sleep(0.25)
			print("-"*50)
		Table.L.release() # Step-3

#main program
Table.getLock() # Call Class Level method for Initiating Lock object
#Create Multiple Sub threads
t1=threading.Thread(target=Table(10).multable)
t2=threading.Thread(target=Table(-12).multable)
t3=threading.Thread(target=Table(13).multable)
t4=threading.Thread(target=Table(19).multable)
#dispatch the threads
t1.start()
t2.start()
t3.start()
t4.start()