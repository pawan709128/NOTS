#Program for withdrawing the amount from same account by multiple customers
#BankTransOOPsEx1.py
import threading,time
class BankTrans:
	@classmethod
	def getaccBal(cls):
		print("-------------------------------------------------------------")
		cls.accbal=20000
		print("INITIAL ACCOUNT BALANCE:{}".format(cls.accbal))
		print("-------------------------------------------------------------")
	def  __init__(self,wamt):
		self.wamt=amt
	
	def withdraw(self):
		print("-------------------------------------------------------------")
		if(self.wamt>BankTrans.accbal):
			print("Dear Customer {}, INR {}  Not Available in this Account-Failed".format(threading.current_thread().name,self.wamt))
			time.sleep(5)
		else:
			BankTrans.accbal=BankTrans.accbal-self.wamt
			print("Dear Customer {}, Take INR {} Cash -Successful".format(threading.current_thread().name,self.wamt))
			time.sleep(5)
			print("Now ACCOUNT BALANCE:{}".format(cls.accbal))
			print("-------------------------------------------------------------")


#main program
BankTrans.getaccBal()
#create multiple threads (customers)
t1=threading.Thread(target=BankTrans(1000).withdraw)
t1.name="Rajesh"
t2=threading.Thread(target=BankTrans(4000).withdraw)
t2.name="Naresh"
t3=threading.Thread(target=BankTrans(18000).withdraw)
t3.name="Vinay"
t4=threading.Thread(target=BankTrans(4000).withdraw)
t4.name="Naveen"
t5=threading.Thread(target=BankTrans(12000).withdraw)
t5.name="Rakesh"
t6=threading.Thread(target=BankTrans(11000).withdraw)
t6.name="Raj"
#dispatch the threads
t1.start()
t2.start()
t3.start()
t4.start()
t5.start()
t6.start()
